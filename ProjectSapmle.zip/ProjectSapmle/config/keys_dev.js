const MongoClient = require('mongodb').MongoClient;
const uri =
    'mongodb+srv://ok123:ok123@tmcluster-toabq.mongodb.net/test?retryWrites=true&w=majority';
const client = new MongoClient(uri, { useNewUrlParser: true });
client.connect(err => {
    const collection = client.db('test').collection('devices');
    // perform actions on the collection object
    client.close();
});

module.exports = {
    mongoURI: uri,
    secretOrKey: 'SECRET'
};